package com.mycompany;

import org.apache.wicket.Session;
import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.form.PasswordTextField;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.model.Model;
import org.apache.wicket.markup.html.WebPage;
import com.mycompany.basic.User;
import com.mycompany.db.UserDAO;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.io.UnsupportedEncodingException;

public class Register extends WebPage {
	private static final long serialVersionUID = 1L;
    private Form form;
    private TextField name;
    private TextField email;
    private TextField course;
    private TextField instituition;
    private TextField profilename;
    private TextField login;
    private PasswordTextField password;

	public Register() {
		super();
        form = new Form("register");
        name = new TextField("name", new Model(""));
        email = new TextField("email", new Model(""));
        course = new TextField("course", new Model(""));
        instituition = new TextField("instituition", new Model(""));
        profilename = new TextField("profilename", new Model(""));
        login = new TextField("login", new Model(""));
        password = new PasswordTextField("password", new Model(""));
        form.add(name);
        form.add(email);
        form.add(course);
        form.add(instituition);
        form.add(profilename);
        form.add(login);
        form.add(password);
        form.add(new Button("go"){
           @Override
            public void onSubmit(){
                User user = new User();
                user.setName( (String) name.getModelObject());
                user.setEmail( (String) email.getModelObject());
                user.setCourse( (String) course.getModelObject());
                user.setInstituition((String) instituition.getModelObject());
                user.setProfileName((String) profilename.getModelObject());
                user.setLogin((String) login.getModelObject());
                //user.setPassword((String) password.getModelObject());
                user.setPassword(getHash((String) password.getModelObject()));
                getSession().setAttribute("user", user);
                
                UserDAO uman = new UserDAO();
                uman.add(user);
                
                setResponsePage(new Home());
            }
        });
        add(form);
		// TODO Add your page's components here

    }
    
    public String getHash(String pass){
        String hash = "";
        try{
            MessageDigest algorithm = MessageDigest.getInstance("md5");
            byte messageDigest[] = algorithm.digest(pass.getBytes("utf-8"));
            
            hash = new String(messageDigest,"utf-8");
            
        }catch(NoSuchAlgorithmException noalg){
            System.out.println("Algorithm not found!");
        }catch(UnsupportedEncodingException uee){
            System.out.println("Encoding unsupported!");
        }
        //return(hash);
        return(pass);
    }
}
