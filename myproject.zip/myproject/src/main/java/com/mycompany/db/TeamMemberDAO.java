package com.mycompany.db;

import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import com.mycompany.basic.TeamMember;

public class TeamMemberDAO{
    
    //add
    public boolean add(TeamMember member){
        boolean resp = false;
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "insert into equipe values(null,?,?,0)";
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setInt(1,member.getMember());
            pstm.setString(2,member.getTeam());
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    
    //remove
    public boolean remove(int member_id){
        boolean resp = false;
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "delete from equipe where id=?";
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setInt(1,member_id);
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    
    //update
    public boolean update(TeamMember member){
        boolean resp = false;
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "update equipe set membro=?, nomeequipe=?, idprojeto=? where id=?";
            pstm = connection.getConnection().prepareStatement(sql);
            
            pstm.setInt(1,member.getMember());
            pstm.setString(2,member.getTeam());
            pstm.setInt(3,member.getProject());
            pstm.setInt(4,member.getId());
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    //get
    public TeamMember get(int member_id){
        TeamMember temp = new TeamMember();
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "select * from equipe where id=?";
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setInt(1,member_id);
            ResultSet rs = pstm.executeQuery();
            
            while(rs.next()){
                temp.setId(rs.getInt("id"));
                temp.setMember(rs.getInt("membro"));
                temp.setTeam(rs.getString("nomeequipe"));
                temp.setProject(rs.getInt("idprojeto"));
            }
            
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(temp);
    }
    //list
    
    public ArrayList list(){
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        ArrayList<TeamMember> members = new ArrayList();
        try{
            connection = new ConnectionDB();
            String sql = "select * from equipe";
            pstm = connection.getConnection().prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            
            while(rs.next()){
                TeamMember temp = new TeamMember();
                temp.setId(rs.getInt("id"));
                temp.setMember(rs.getInt("membro"));
                temp.setTeam(rs.getString("nomeequipe"));
                temp.setProject(rs.getInt("idprojeto"));
                members.add(temp);
            }
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(members);
    }
}