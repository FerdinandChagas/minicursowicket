package com.mycompany.db;

import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import com.mycompany.basic.Item;

public class ItemDAO{
    
    //add
    public boolean add(Item item){
        boolean resp = false;
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "insert into material values(null,?,?,?)";
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setString(1,item.getDate());
            pstm.setString(2,item.getDescription());
            pstm.setString(3,item.getLink());
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    
    //remove
    public boolean remove(int item_id){
        boolean resp = false;
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "delete from material where id=?";
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setInt(1,item_id);
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    
    //update
    public boolean update(Item item){
        boolean resp = false;
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "update material set data=?, descricao=?, link=? where id=?";
            pstm = connection.getConnection().prepareStatement(sql);
            
            pstm.setString(1,item.getDate());
            pstm.setString(2,item.getDescription());
            pstm.setString(3,item.getLink());
            pstm.setInt(4,item.getId());
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    //get
    public Item get(int item_id){
        Item temp = new Item();
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "select * from material where id=?";
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setInt(1,item_id);
            ResultSet rs = pstm.executeQuery();
            
            while(rs.next()){
                temp.setId(rs.getInt("id"));
                temp.setDate(rs.getString("data"));
                temp.setDescription(rs.getString("descricao"));
                temp.setLink(rs.getString("link"));
            }
            
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(temp);
    }
    //list
    
    public ArrayList list(){
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        ArrayList<Item> item = new ArrayList();
        try{
            connection = new ConnectionDB();
            String sql = "select * from material";
            pstm = connection.getConnection().prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            
            while(rs.next()){
                Item temp = new Item();
                temp.setId(rs.getInt("id"));
                temp.setDate(rs.getString("data"));
                temp.setDescription(rs.getString("descricao"));
                temp.setLink(rs.getString("link"));
                item.add(temp);
            }
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(item);
    }
}