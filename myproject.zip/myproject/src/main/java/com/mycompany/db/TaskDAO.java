package com.mycompany.db;

import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import com.mycompany.basic.Task;

public class TaskDAO{
    
    //add
    public boolean add(Task task){
        boolean resp = false;
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "insert into cronograma values(null,?,?)";
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setString(1,task.getDate());
            pstm.setString(2,task.getDescription());
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    
    //remove
    public boolean remove(int task_id){
        boolean resp = false;
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "delete from cronograma where id=?";
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setInt(1,task_id);
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    
    //update
    public boolean update(Task task){
        boolean resp = false;
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "update cronograma set data=?, descricao=? where id=?";
            pstm = connection.getConnection().prepareStatement(sql);
            
            pstm.setString(1,task.getDate());
            pstm.setString(2,task.getDescription());
            pstm.setInt(3,task.getId());
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    //get
    public Task get(int task_id){
        Task temp = new Task();
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "select * from cronograma where id=?";
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setInt(1,task_id);
            ResultSet rs = pstm.executeQuery();
            
            while(rs.next()){
                temp.setId(rs.getInt("id"));
                temp.setDate(rs.getString("data"));
                temp.setDescription(rs.getString("descricao"));
            }
            
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(temp);
    }
    //list
    
    public ArrayList list(){
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        ArrayList<Task> tasks = new ArrayList();
        try{
            connection = new ConnectionDB();
            String sql = "select * from cronograma";
            pstm = connection.getConnection().prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            
            while(rs.next()){
                Task temp = new Task();
                temp.setId(rs.getInt("id"));
                temp.setDate(rs.getString("data"));
                temp.setDescription(rs.getString("descricao"));
                tasks.add(temp);
            }
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(tasks);
    }
}