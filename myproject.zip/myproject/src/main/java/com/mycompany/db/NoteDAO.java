package com.mycompany.db;

import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import com.mycompany.basic.Note;

public class NoteDAO{
    
    //add
    public boolean add(Note news){
        boolean resp = false;
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "insert into noticias values(null,?,?,?)";
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setString(1,news.getDate());
            pstm.setString(2,news.getTitle());
            pstm.setString(3,news.getDescription());
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    
    //remove
    public boolean remove(int news_id){
        boolean resp = false;
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "delete from noticias where id=?";
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setInt(1,news_id);
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    
    //update
    public boolean update(Note news){
        boolean resp = false;
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "update noticias set data=?, titulo=?, descricao=? where id=?";
            pstm = connection.getConnection().prepareStatement(sql);
            
            pstm.setString(1,news.getDate());
            pstm.setString(2,news.getTitle());
            pstm.setString(3,news.getDescription());
            pstm.setInt(4,news.getId());
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    //get
    public Note get(int news_id){
        Note temp = new Note();
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "select * from noticias where id=?";
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setInt(1,news_id);
            ResultSet rs = pstm.executeQuery();
            
            while(rs.next()){
                temp.setId(rs.getInt("id"));
                temp.setDate(rs.getString("data"));
                temp.setTitle(rs.getString("titulo"));
                temp.setDescription(rs.getString("descricao"));
            }
            
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(temp);
    }
    //list
    
    public ArrayList list(){
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        ArrayList<Note> news = new ArrayList();
        try{
            connection = new ConnectionDB();
            String sql = "select * from noticias";
            pstm = connection.getConnection().prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            
            while(rs.next()){
                Note temp = new Note();
                temp.setId(rs.getInt("id"));
                temp.setDate(rs.getString("data"));
                temp.setTitle(rs.getString("titulo"));
                temp.setDescription(rs.getString("descricao"));
                news.add(temp);
            }
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(news);
    }
}