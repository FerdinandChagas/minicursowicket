package com.mycompany.db;

import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import com.mycompany.basic.Project;

public class ProjectDAO{
    
    //add
    public boolean add(Project project){
        boolean resp = false;
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "insert into projeto values(null,?,?)";
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setString(1,project.getName());
            pstm.setString(2,project.getDescription());
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    
    //remove
    public boolean remove(int project_id){
        boolean resp = false;
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "delete from projeto where id=?";
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setInt(1,project_id);
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    
    //update
    public boolean update(Project project){
        boolean resp = false;
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "update projeto set nome=?, descricao=? where id=?";
            pstm = connection.getConnection().prepareStatement(sql);
            
            pstm.setString(1,project.getName());
            pstm.setString(2,project.getDescription());
            pstm.setInt(3,project.getId());
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    //get
    public Project get(int project_id){
        Project temp = new Project();
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        try{
            connection = new ConnectionDB();
            String sql = "select * from projeto where id=?";
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setInt(1,project_id);
            ResultSet rs = pstm.executeQuery();
            
            while(rs.next()){
                temp.setId(rs.getInt("id"));
                temp.setName(rs.getString("nome"));
                temp.setDescription(rs.getString("descricao"));
            }
            
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(temp);
    }
    //list
    
    public ArrayList list(){
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        ArrayList<Project> projects = new ArrayList();
        try{
            connection = new ConnectionDB();
            String sql = "select * from projeto";
            pstm = connection.getConnection().prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            
            while(rs.next()){
                Project temp = new Project();
                temp.setId(rs.getInt("id"));
                temp.setName(rs.getString("nome"));
                temp.setDescription(rs.getString("descricao"));
                projects.add(temp);
            }
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(projects);
    }
}