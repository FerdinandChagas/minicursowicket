/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mycompany.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author les
 */
public class ConnectionDB {
    private Connection conn = null;

    public ConnectionDB() throws SQLException, ClassNotFoundException{
        conn = this.getConnection();
    }
	public Connection getConnection() throws SQLException, ClassNotFoundException{
		try{
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/minicurso";
			String user = "root";
			String password = "";
			conn = (Connection) DriverManager.getConnection(url,user,password);
		}
		catch(SQLException e){
			System.out.println("SQLException: "+e.getMessage());
		}
        return conn;
	}

    public void closeConnection(){
        try {
            if(conn!=null)conn.close();
        } catch (SQLException ex) {
            System.out.println("Exception class ConnectionDB(closeConnection): " + ex.getMessage());
        }
    }
}
