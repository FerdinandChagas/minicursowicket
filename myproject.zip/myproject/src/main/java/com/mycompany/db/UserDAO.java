package com.mycompany.db;

import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import com.mycompany.basic.User;


public class UserDAO{
    
    //Add
    public boolean add(User user){
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        String sql = "insert into usuario values(null,?,?,?,?,?,?,?,2,null)";
        boolean resp = false;
        try{
            connection = new ConnectionDB();
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setString(1,user.getName());
            pstm.setString(2,user.getEmail());
            pstm.setString(3,user.getCourse());
            pstm.setString(4,user.getInstituition());
            pstm.setString(5,user.getProfileName());
            pstm.setString(6,user.getLogin());
            pstm.setString(7,user.getPassword());
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    
    //Remove
    public boolean remove(int user_id){
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        String sql = "delete from usuario where id=?";
        boolean resp = false;
        try{
            connection = new ConnectionDB();
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setInt(1,user_id);
            pstm.execute();
            resp=true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    
    //Update
    public boolean update(User user){
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        String sql = "update usuario set nome=? , email=?, curso=?, instituicao=?, nomeexibicao=?, login=?, senha=?, nivel=?, idequipe=? where id=?";
        boolean resp = false;
        try{
            connection = new ConnectionDB();
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setString(1,user.getName());
            pstm.setString(2,user.getEmail());
            pstm.setString(3,user.getCourse());
            pstm.setString(4,user.getInstituition());
            pstm.setString(5,user.getProfileName());
            pstm.setString(6,user.getLogin());
            pstm.setString(7,user.getPassword());
            pstm.setInt(8,user.getLevel());
            pstm.setInt(9,user.getTeam());
            pstm.setInt(10,user.getId());
            pstm.execute();
            
            resp = true;
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(resp);
    }
    
    //List
    public ArrayList<User> list(){
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        String sql = "select * from usuario";
        ArrayList<User> users = new ArrayList();
        try{
            connection = new ConnectionDB();
            pstm = connection.getConnection().prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            
            while(rs.next()){
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("nome"));
                user.setEmail(rs.getString("email"));
                user.setCourse(rs.getString("curso"));
                user.setInstituition(rs.getString("instituicao"));
                user.setProfileName(rs.getString("nomeexibicao"));
                user.setLogin(rs.getString("login"));
                user.setPassword(rs.getString("senha"));
                user.setLevel(rs.getInt("nivel"));
                user.setTeam(rs.getInt("idequipe"));
                users.add(user);
            }
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(users);
    }
    
    //Get
    public User get(String login){
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        String sql = "select * from usuario where login=?";
        User user = new User();
        try{
            connection = new ConnectionDB();
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setString(1,login);
            ResultSet rs = pstm.executeQuery();
            
            while(rs.next()){
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("nome"));
                user.setEmail(rs.getString("email"));
                user.setCourse(rs.getString("curso"));
                user.setInstituition(rs.getString("instituicao"));
                user.setProfileName(rs.getString("nomeexibicao"));
                user.setLogin(rs.getString("login"));
                user.setPassword(rs.getString("senha"));
                user.setLevel(rs.getInt("nivel"));
                user.setTeam(rs.getInt("idequipe"));
            }
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(user);
    }
    
    //Recover
    public User recover(String email){
        ConnectionDB connection = null;
        PreparedStatement pstm = null;
        String sql = "select * from usuario where email=?";
        User user = new User();
        try{
            connection = new ConnectionDB();
            pstm = connection.getConnection().prepareStatement(sql);
            pstm.setString(1, email);
            ResultSet rs = pstm.executeQuery();
            
            while(rs.next()){
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("nome"));
                user.setEmail(rs.getString("email"));
                user.setCourse(rs.getString("curso"));
                user.setInstituition(rs.getString("instituicao"));
                user.setProfileName(rs.getString("nomeexibicao"));
                user.setLogin(rs.getString("login"));
                user.setPassword(rs.getString("senha"));
                user.setLevel(rs.getInt("nivel"));
                user.setTeam(rs.getInt("idequipe"));
            }
        }catch(ClassNotFoundException ex){
            //System.out.println("ERRO: Erro no sql =\\");
        }catch(SQLException ex2){
            //System.out.println("ERRO: "+ex2.getMessage());
        }finally{
            try{
                if(pstm!=null){
                    pstm.close();
                }
                connection.closeConnection();
            }catch(SQLException e) { 
                // LOGGING 
                e.printStackTrace(); 
            } 
        }
        return(user);
    }
    
}