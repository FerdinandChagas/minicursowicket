package com.mycompany.email;



public class Email {
    private String remetente;
    private String destinatario;
    private String assunto;
    private String mensagem;

    public Email(){

    }
    public Email(String remetente, String destinatario, String assunto, String mensagem){
        this.remetente=remetente;
        this.destinatario=destinatario;
        this.assunto=assunto;
        this.mensagem=mensagem;
    }

    public String getAssunto() {
        return assunto;
    }

    public void setAssunto(String assunto) {
        this.assunto = assunto;
    }

    public String getDestinatario() {
        return destinatario;
    }

    public void setDestinatario(String destinatario) {
        this.destinatario = destinatario;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getRemetente() {
        return remetente;
    }

    public void setRemetente(String remetente) {
        this.remetente = remetente;
    }

	/*Exemplo de utilização
	    Email email = new Email();
            String email_gerente = getEmailGerente(id_projeto);
            email.setDestinatario(email_gerente);
            email.setAssunto("[Asssistente de Projeto] - Notificação");
            email.setMensagem(mensagem);
            SMTP aux = new SMTP(email);
            aux.sendEmail();
	*/

}
