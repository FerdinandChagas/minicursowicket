package com.mycompany;

import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.model.Model;
import com.mycompany.email.Email;
import com.mycompany.email.SMTP;
import com.mycompany.basic.User;
import com.mycompany.db.UserDAO;

public class Forget extends WebPage {
	private static final long serialVersionUID = 1L;
    private Form form;
    private TextField email;

	public Forget() {
		super();
        
        add(new Link("back"){
            @Override
            public void onClick(){
                setResponsePage(StartPage.class);
            }
        });
		
        form = new Form("passwordrecover");
        email = new TextField("email", new Model(""));
        form.add(email);
        form.add(new Button("recover"){
           @Override
            public void onSubmit(){
                /*  MECANISMO DESATIVADO TEMPORARIAMENTE SERÁ REATIVADO NA FASE DE TESTES E IMPLANTAÇÃO
                User temp = new UserDAO().recover((String) email.getModelObject());
                Email recmail = new Email();
                recmail.setDestinatario(temp.getEmail());
                recmail.setMensagem("Este é um email para recuperação de senha. \n\n\n\nLogin:"+temp.getLogin()+"\nSenha:"+temp.getPassword());
                recmail.setAssunto("[Minicurso Wicket] - Recuperação de Senha");
                SMTP service = new SMTP(recmail);
                service.sendEmail();*/
                setResponsePage(StartPage.class);
            }
        });
        add(form);

		// TODO Add your page's components here

    }
}
