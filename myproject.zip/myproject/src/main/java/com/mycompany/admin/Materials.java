package com.mycompany.admin;

import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.list.ListItem;
import com.mycompany.basic.Item;
import com.mycompany.db.ItemDAO;
import java.util.ArrayList;

public class Materials extends WebPage {
	private static final long serialVersionUID = 1L;

	public Materials() {
		super();

        add(new Link("back"){
            @Override
            public void onClick(){
                setResponsePage(Admin.class);
            }
        });
        
        ArrayList<Item> content = new ItemDAO().list();
        ListView materials = new ListView("materials",content){
            
            protected void populateItem(ListItem item){
                Item temp = (Item) item.getModelObject();
                item.add(new Label("id", temp.getId()));
                item.add(new Label("date", temp.getDate()));
                item.add(new Label("description", temp.getDescription()));
                item.add(new Label("link", temp.getLink()));
            }
        };
        add(materials);
        
        

		// TODO Add your page's components here

    }
}
