package com.mycompany.admin;

import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.request.cycle.RequestCycle;
import com.mycompany.basic.User;
import java.lang.NullPointerException;
import com.mycompany.StartPage;

public class Admin extends WebPage {
	private static final long serialVersionUID = 1L;

	public Admin() {
		super();
        
        User user = (User) getSession().getAttribute("user");
                 
        String username = "";
        if(user!=null){
            username = user.getProfileName();
        }else{
            logOut();
        }
        add(new Label("name", "Hello "+username+"!"));
        
        add(new Link("teams"){
            @Override
            public void onClick(){
                setResponsePage(new Teams());
            }
        });
        
        add(new Link("news"){
           @Override
            public void onClick(){
                setResponsePage(new News());
            }
        });
        
        add(new Link("materials"){
            @Override
            public void onClick(){
                setResponsePage(new Materials());
            }
        });
        
        add(new Link("projects"){
            @Override
            public void onClick(){
                setResponsePage(new Projects());
            }
        });
        
        add(new Link("users"){
            @Override
            public void onClick(){
                setResponsePage(new Users());
            }
        });
    
        add(new Link("exit"){
            @Override
            public void onClick(){
                logOut();
            }
        });
        
        
		// TODO Add your page's components here

    }
    
    public void logOut(){
        getSession().invalidate();
        setResponsePage(StartPage.class);
    }
}
