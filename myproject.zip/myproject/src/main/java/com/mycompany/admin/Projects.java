package com.mycompany.admin;

import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.list.ListItem;
import com.mycompany.basic.Project;
import com.mycompany.db.ProjectDAO;
import java.util.ArrayList;

public class Projects extends WebPage {
	private static final long serialVersionUID = 1L;

	public Projects() {
		super();

        add(new Link("back"){
            @Override
            public void onClick(){
                setResponsePage(Admin.class);
            }
        });
        
        ArrayList<Project> content = new ProjectDAO().list();
        ListView projects = new ListView("projects",content){
            
            protected void populateItem(ListItem item){
                Project temp = (Project) item.getModelObject();
                item.add(new Label("id", temp.getId()));
                item.add(new Label("name", temp.getName()));
                item.add(new Label("description", temp.getDescription()));
            }
        };
        add(projects);
        
        

		// TODO Add your page's components here

    }
}
