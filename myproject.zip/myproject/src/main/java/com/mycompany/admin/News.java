package com.mycompany.admin;

import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.ajax.AjaxSelfUpdatingTimerBehavior;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.ajax.markup.html.form.AjaxSubmitLink;
import org.apache.wicket.ajax.markup.html.AjaxLink;
import org.apache.wicket.markup.html.WebMarkupContainer;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.form.TextArea;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.ajax.AjaxRequestTarget;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.model.Model;
import com.mycompany.basic.Note;
import com.mycompany.db.NoteDAO;
import java.util.ArrayList;
import org.apache.wicket.util.time.Duration;

public class News extends WebPage {
	private static final long serialVersionUID = 1L;
    private int count;
    private Label counter;
    private final TextField date;
    private final TextField title;
    private final TextArea description;
    private ListView news;
    private final WebMarkupContainer parent;
    private Form form;
    private ArrayList<Note> notes;
    
	public News() {
		super();
        
        parent = new WebMarkupContainer("newstab");
        parent.setOutputMarkupId(true); 
        add(parent);
        notes = getContent();
        parent.add(new ListView("list", notes) {
            @Override
            protected void populateItem(ListItem item) {
                Note temp = (Note) item.getModelObject();
                item.add(new Label("tdate", new Model(temp.getDate())));
                item.add(new Label("ttitle", new Model(temp.getTitle())));
                item.add(new Label("tdescription", new Model(temp.getDescription())));
            }
        });
        
        Form form = new Form("form");
        date = new TextField("date", new Model(""));
        title = new TextField("title", new Model(""));
        description = new TextArea("description", new Model(""));
        
        date.setOutputMarkupId(true);
        title.setOutputMarkupId(true);
        description.setOutputMarkupId(true);
        
        form.add(date);
        form.add(title);
        form.add(description);
        
        form.add(new AjaxSubmitLink("save") {
            @Override
            protected void onSubmit(AjaxRequestTarget target, Form form) {
                Note temp = new Note();
                temp.setDate((String) date.getModelObject());
                temp.setTitle((String) title.getModelObject());
                temp.setDescription((String) description.getModelObject());
                notes.add(temp);
                NoteDAO mnote = new NoteDAO();
                mnote.add(temp);
                target.add(parent);
                target.focusComponent(date);
            }
        });
        add(form);
        
            
        add(new Link("back"){
            @Override
            public void onClick(){
                setResponsePage(Admin.class);
            }
        });

		// TODO Add your page's componentshere

    }
    
    public ArrayList<Note> getContent(){
        return new NoteDAO().list();
    }
}
