package com.mycompany.admin;

import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.list.ListItem;
import com.mycompany.basic.User;
import com.mycompany.db.UserDAO;
import java.util.ArrayList;

public class Users extends WebPage {
	private static final long serialVersionUID = 1L;

	public Users() {
		super();

        add(new Link("back"){
            @Override
            public void onClick(){
                setResponsePage(Admin.class);
            }
        });
        
        ArrayList<User> content = new UserDAO().list();
        ListView users = new ListView("users",content){
            
            protected void populateItem(ListItem item){
                User temp = (User) item.getModelObject();
                item.add(new Label("id", temp.getId()));
                item.add(new Label("name", temp.getName()));
                item.add(new Label("email", temp.getEmail()));
                item.add(new Label("team", temp.getTeam()));
            }
        };
        add(users);
        
        

		// TODO Add your page's components here

    }
}
