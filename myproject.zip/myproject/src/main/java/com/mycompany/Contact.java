package com.mycompany;

import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.form.TextArea;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.model.Model;
import com.mycompany.email.Email;
import com.mycompany.email.SMTP;
import org.apache.wicket.markup.html.WebPage;

public class Contact extends WebPage {
	private static final long serialVersionUID = 1L;
    private Form form;
    private TextField name;
    private TextField email;
    private TextArea message;

	public Contact() {
		super();
        form = new Form("contact");
        name = new TextField("name", new Model(""));
        email = new TextField("email", new Model(""));
        message = new TextArea("message", new Model(""));
        form.add(name);
        form.add(email);
        form.add(message);
        form.add(new Button("send"){
            @Override
            public void onSubmit(){
                Email temp = new Email();
                temp.setRemetente((String) email.getModelObject());
                temp.setMensagem(((String) message.getModelObject())+"\n\n\n"+name.getModelObject()+"\n"+temp.getRemetente());
                temp.setAssunto("[Minicurso Wicket]");
                temp.setDestinatario("ferdinandy@ufersa.edu.br");
                SMTP service = new SMTP(temp);
                service.sendEmail();
                setResponsePage(Home.class);
            }
            
        });
        add(form);
        add(new Link("back"){
            @Override
            public void onClick(){
                setResponsePage(Home.class);
            }
        });
		

		// TODO Add your page's components here

    }
}
