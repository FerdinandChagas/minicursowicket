package com.mycompany;

import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.list.ListItem;
import com.mycompany.basic.TeamMember;
import com.mycompany.db.TeamMemberDAO;
import java.util.ArrayList;

public class Team extends WebPage {
	private static final long serialVersionUID = 1L;

	public Team() {
		super();
        
        add(new Link("back"){
            @Override
            public void onClick(){
                setResponsePage(Home.class);
            }
        });
        
        ArrayList<TeamMember> content = new TeamMemberDAO().list();
        ListView members = new ListView("members",content){
            
            protected void populateItem(ListItem item){
                TeamMember temp = (TeamMember) item.getModelObject();
                item.add(new Label("id", temp.getId()));
                item.add(new Label("member", temp.getMember()));
                item.add(new Label("team", temp.getTeam()));
                item.add(new Label("project", temp.getProject()));
            }
        };
        add(members);
        

    }
}
