package com.mycompany;

import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.list.ListItem;
import com.mycompany.basic.Task;
import com.mycompany.db.TaskDAO;
import java.util.ArrayList;

public class Schedule extends WebPage {
	private static final long serialVersionUID = 1L;

	public Schedule() {
		super();

        add(new Link("back"){
            @Override
            public void onClick(){
                setResponsePage(Home.class);
            }
        });
        
        ArrayList<Task> content = new TaskDAO().list();
        ListView tasks = new ListView("tasks",content){
            
            protected void populateItem(ListItem item){
                Task temp = (Task) item.getModelObject();
                item.add(new Label("id", temp.getId()));
                item.add(new Label("date", temp.getDate()));
                item.add(new Label("description", temp.getDescription()));
            }
        };
        add(tasks);
        
        

		// TODO Add your page's components here

    }
}
