package com.mycompany;

import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.request.cycle.RequestCycle;
import com.mycompany.basic.User;
import java.lang.NullPointerException;

public class Home extends WebPage {
	private static final long serialVersionUID = 1L;

	public Home() {
		super();
        
        User user = (User) getSession().getAttribute("user");
                 
        String username = "";
        if(user!=null){
            username = user.getProfileName();
        }else{
            logOut();
        }
        add(new Label("name", "Hello "+username+"!"));
        
        add(new Link("news"){
            @Override
            public void onClick(){
                setResponsePage(new News());
            }
        });
        
        add(new Link("material"){
            @Override
            public void onClick(){
                setResponsePage(new Material());
            }
        });
        
        add(new Link("team"){
            @Override
            public void onClick(){
                setResponsePage(new Team());
            }
        });
        
        add(new Link("schedule"){
            @Override
            public void onClick(){
                setResponsePage(new Schedule());
            }
        });
        
        add(new Link("profile"){
            @Override
            public void onClick(){
                setResponsePage(new Profile());
            }
            
        });
        
        add(new Link("exit"){
            @Override
            public void onClick(){
                logOut();
            }
        });
        
        
		// TODO Add your page's components here

    }
    
    public void logOut(){
        getSession().invalidate();
        setResponsePage(StartPage.class);
    }
}
