package com.mycompany;

import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.markup.html.list.ListItem;
import com.mycompany.basic.Note;
import com.mycompany.db.NoteDAO;
import java.util.ArrayList;

public class News extends WebPage {
	private static final long serialVersionUID = 1L;

	public News() {
		super();

        add(new Link("back"){
            @Override
            public void onClick(){
                setResponsePage(Home.class);
            }
        });
        
        ArrayList<Note> content = new NoteDAO().list();
        ListView news = new ListView("news",content){
            
            protected void populateItem(ListItem item){
                Note temp = (Note) item.getModelObject();
                item.add(new Label("idn", temp.getId()));
                item.add(new Label("daten", temp.getDate()));
                item.add(new Label("titlen", temp.getTitle()));
                item.add(new Label("description", temp.getDescription()));
            }
        };
        add(news);
        
        

		// TODO Add your page's components here

    }
}
