package com.mycompany.basic;

import java.io.Serializable;

public class User implements Serializable{
    
    private int id;
    private String name;
    private String email;
    private String course;
    private String instituition;
    private String profilename;
    private String login;
    private String password;
    private int level;
    private int team;
    
    public User(){
        
    }
    
    public void setId(int id){
        this.id=id;
    }
    
    public void setName(String name){
        this.name=name;
    }
    
    public void setEmail(String email){
        this.email=email;
    }
    
    public void setCourse(String course){
        this.course=course;
    }
    
    public void setInstituition(String instituition){
        this.instituition=instituition;
    }
    
    public void setProfileName(String profilename){
        this.profilename=profilename;
    }
    
    public void setLogin(String login){
        this.login=login;
    }
    
    public void setPassword(String password){
        this.password=password;
    }
    
    public void setLevel(int level){
        this.level=level;
    }
    
    public void setTeam(int team){
        this.team=team;
    }
    
    public int getId(){
        return this.id;
    }
    
    public String getName(){
        return this.name;
    }
    
    public String getEmail(){
        return this.email;
    }
    
    public String getCourse(){
        return this.course;
    }
    
    public String getInstituition(){
        return this.instituition;
    }
    
    public String getLogin(){
        return this.login;
    }
    
    public String getProfileName(){
        return this.profilename;
    }
    
    public String getPassword(){
        return this.password;
    }
    
    public int getLevel(){
        return this.level;
    }
    
    public int getTeam(){
        return this.team;
    }
}