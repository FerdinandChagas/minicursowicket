package com.mycompany.basic;

import java.io.Serializable;

public class TeamMember implements Serializable{
    private int id;
    private int member;
    private String team;
    private int id_project;
    
    public void setId(int id){
        this.id=id;
    }
    
    public void setMember(int member){
        this.member=member;
    }
    
    public void setTeam(String team){
        this.team=team;
    }
    
    public void setProject(int id_project){
        this.id_project=id_project;
    }
    
    public int getId(){
        return this.id;
    }
    
    public int getMember(){
        return this.member;
    }
    
    public String getTeam(){
        return this.team;
    }
    
    public int getProject(){
        return this.id_project;
    }
}