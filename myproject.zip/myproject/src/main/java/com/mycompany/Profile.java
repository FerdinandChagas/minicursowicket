package com.mycompany;

import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.form.PasswordTextField;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.model.Model;
import org.apache.wicket.markup.html.WebPage;
import com.mycompany.basic.User;
import com.mycompany.db.UserDAO;

public class Profile extends WebPage {
	private static final long serialVersionUID = 1L;
    private Form form;
    private TextField name;
    private TextField email;
    private TextField course;
    private TextField instituition;
    private TextField profilename;
    private TextField login;

	public Profile() {
		super();
        
        final User user = (User) getSession().getAttribute("user");
        
        
        form = new Form("register");
        name = new TextField("name", new Model(user.getName()));
        email = new TextField("email", new Model(user.getEmail()));
        course = new TextField("course", new Model(user.getCourse()));
        instituition = new TextField("instituition", new Model(user.getInstituition()));
        profilename = new TextField("profilename", new Model(user.getProfileName()));
        form.add(name);
        form.add(email);
        form.add(course);
        form.add(instituition);
        form.add(profilename);
        form.add(new Button("go"){
           @Override
            public void onSubmit(){
                User temp = new User();
                temp.setId(user.getId());
                temp.setName((String) name.getModelObject());
                temp.setEmail((String) email.getModelObject());
                temp.setCourse((String) course.getModelObject());
                temp.setInstituition((String) instituition.getModelObject());
                temp.setProfileName((String) profilename.getModelObject());
                temp.setLogin(user.getLogin());
                temp.setPassword(user.getPassword());
                UserDAO uman = new UserDAO();
                uman.update(temp);
                getSession().setAttribute("user",temp);
                setResponsePage(Home.class);
            }
        });
        add(form);
        
        add(new Link("back"){
            @Override
            public void onClick(){
                setResponsePage(Home.class);
            }
        });
		// TODO Add your page's components here

    }
}
