package com.mycompany;

import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.WebPage;

public class Teacher extends WebPage {
	private static final long serialVersionUID = 1L;

	public Teacher() {
		super();

		

		// TODO Add your page's components here

    }
}
