package com.mycompany;

import com.mycompany.basic.User;
import org.apache.wicket.request.mapper.parameter.PageParameters;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.form.PasswordTextField;
import org.apache.wicket.markup.html.form.Button;
import org.apache.wicket.markup.html.link.Link;
import org.apache.wicket.model.Model;
import org.apache.wicket.markup.html.WebPage;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.io.UnsupportedEncodingException;
import com.mycompany.db.UserDAO;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mycompany.admin.Admin;


public class StartPage extends WebPage {
	private static final long serialVersionUID = 1L;
    private TextField login;
    private TextField password;
    

	public StartPage(final PageParameters parameters) {
		super(parameters);

        Form form = new Form("enter");
        login = new TextField("login", new Model(""));
        password = new PasswordTextField("password", new Model(""));
        form.add(login);
        form.add(password);
        form.add(new Button("start"){
            @Override
            public void onSubmit(){
                String log = (String) login.getModelObject();
                String pass = (String) password.getModelObject();
                if(isAuth(log,pass)){
                    User temp = (User) getSession().getAttribute("user");
                    if(temp.getLevel()==1){
                        setResponsePage(new Admin());
                    }else{
                        setResponsePage(new Home());    
                    }
                    
                }
            }
        });
        add(form);
        
		add(new Link("forget"){
            @Override
            public void onClick(){
                setResponsePage(new Forget());
            }
        });
            
        add(new Link("register"){
            @Override
            public void onClick(){
                setResponsePage(new Register());
            }
        });
            
        add(new Link("contact"){
            @Override
            public void onClick(){
                setResponsePage(new Contact());
            }
        });
        
    }
    
    public boolean isAuth(String log, String pass){
        boolean resp = false;
        //String passhash = getHash(pass);
        String passhash = pass;
        UserDAO uman = new UserDAO();
        User temp = uman.get(log);

        //System.out.println("HASH1:"+temp.getPassword());
        ///System.out.println("HASH2:"+passhash);

        if(temp.getPassword().equals(passhash)){
            getSession().setAttribute("user",temp);
            resp=true;
        }
        return(resp);
    }
    
    public String getHash(String pass){
        String hash = "";
        try{
            MessageDigest algorithm = MessageDigest.getInstance("md5");
            byte messageDigest[] = algorithm.digest(pass.getBytes("utf-8"));
            //System.out.println(messageDigest);
            hash = new String(messageDigest,"utf-8");
            //System.out.println(hash);
        }catch(NoSuchAlgorithmException noalg){
            System.out.println("Algorithm not found!");
        }catch(UnsupportedEncodingException uee){
            System.out.println("Encoding unsupported!");
        }
        return(hash);
    }
}
